#!/usr/bin/python

print("hi there")
